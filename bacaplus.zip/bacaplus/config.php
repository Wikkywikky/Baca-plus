<?php


$uid="Facebook_xxxxxxxxxxxxxxxxxxx";
$raw_uid="xxxx-xxxx-xxxx-xxxx-xxxx";
$user_name="User+name";
$invite_code="xxxxxxx";
$own_mac="02%xxxx%xxxx%xxxx%xxxx%xxxx";
$android_id="xxxxxxxxxxxx";
$device_type="xxxx++xxxx";


?>